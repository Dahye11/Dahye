from pico2d import *

class Bubble:
    image = None

    def __init__(self, x, y):
        self.x, self.y = x, y
        if self.image == None:
            self.image = load_image('bubble.png')

    def update(self):
        self.y += 5
        if self.y > 570:
            self.y = 570

    def draw(self):
        self.image.draw(self.x, self.y)

    def get_bb(self):
        return self.x - 15, self.y - 15, self.x + 15, self.y + 15

    def draw_bb(self):
        draw_rectangle(*self.get_bb())