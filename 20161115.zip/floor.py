from pico2d import *

class Floor:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def draw(self):
        self.image.draw(self.x, self.y)

    def get_bb(self):
        return self.x - 350, self.y + 5, self.x + 350, self.y + 5

    def draw_bb(self):
        draw_rectangle(*self.get_bb())