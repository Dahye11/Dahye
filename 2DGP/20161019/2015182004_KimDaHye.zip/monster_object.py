import sys
sys.path.append('../LabsAll/Labs')

import game_framework
import random
from pico2d import *

start = None

class Monster1:
    image = None

    LEFT_RUN, RIGHT_RUN = 1, 0


    def handle_left_run(self):
        self.x -= 10
        self.run_frames += 1
        if self.x < 70:
            self.state = self.RIGHT_RUN
            self.x = 70



    def handle_right_run(self):
        self.x += 10
        self.run_frames -= 1
        if self.x > 750:
            self.state = self.LEFT_RUN
            self.x = 750


    handle_state = {
                LEFT_RUN : handle_left_run,
                RIGHT_RUN : handle_right_run,
    }

    def update(self, _events):
        self.frame = (self.frame + 1) % 12
        self.handle_state[self.state](self)

    def __init__(self):
        self.x, self.y = random.randint(100, 700), 90
        self.frame = random.randint(0, 7)
        self.run_frames = 0
        self.stand_frames = 0
        self.state = self.RIGHT_RUN
        if Monster1.image == None:
            Monster1.image = load_image('monster1.PNG')

    def draw(self):
        self.image.clip_draw(self.frame * 40, self.state * 46, 40, 46, self.x, self.y)


class Monster2:
    image = None

    LEFT_RUN, RIGHT_RUN = 1, 0


    def handle_left_run(self):
        self.x -= 10
        self.run_frames += 1
        if self.x < 100:
            self.state = self.RIGHT_RUN
            self.x = 100



    def handle_right_run(self):
        self.x += 10
        self.run_frames -= 1
        if self.x > 700:
            self.state = self.LEFT_RUN
            self.x = 700


    handle_state = {
                LEFT_RUN : handle_left_run,
                RIGHT_RUN : handle_right_run,
    }

    def update(self, _events):
        self.frame = (self.frame + 1) % 8
        self.handle_state[self.state](self)


    def __init__(self):
        self.x, self.y = random.randint(100, 700), 400
        self.frame = random.randint(0, 7)
        self.run_frames = 0
        self.stand_frames = 0
        self.state = self.RIGHT_RUN
        self.dirY = 1
        if Monster2.image == None:
            Monster2.image = load_image('monster2.PNG')

    def draw(self):
        self.image.clip_draw(self.frame * 50, self.state * 46, 50, 46, self.x, self.y)
