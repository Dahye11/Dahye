import game_framework
from player_object import *
from monster_object import *
import stage3
from pico2d import *

name = "Stage2"
globalevents = None
player = None
monster2 = None
backimage1, backimage2, stageimage = None, None,None


def handle_events():
    global globalevents
    globalevents = get_events()
    print(globalevents)
    for event in globalevents:
        if event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                game_framework.quit()
            elif event.key == SDLK_a:
                game_framework.change_state(stage3)
        elif event.type == SDL_QUIT:
            game_framework.quit()

def enter():
    global player, stageimage, backimage1, backimage2, monster2
    open_canvas()
    player = Player()
    monster2 = Monster2()

    backimage1 = load_image('background2_1.png')
    backimage2 = load_image('background2_2.png')
    stageimage = load_image('stage2.png')

def exit():
    global player, stageimage, backimage1, backimage2, monster2
    del(monster2)
    del(player)
    del(stageimage)
    del(backimage1)
    del(backimage2)


def update():
    global player, stageimage, monster2
    monster2.update(globalevents)
    player.update(globalevents)
    delay(0.1)


def draw():
    global player, stageimage, backimage1, backimage2, monster2
    clear_canvas()
    backimage1.draw(400, 300)
    backimage2.draw(400, 300)
    stageimage.draw(400, 300)
    player.draw()
    monster2.draw()
    update_canvas()





