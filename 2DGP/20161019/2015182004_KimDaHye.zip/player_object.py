from pico2d import *
from game_framework import *

#------------------------------------------

class Player:
    image = None

    LEFT_WALK, RIGHT_WALK, LEFT_DIE, RIGHT_DIE = 3,2,1,0


    def handle_left_die(self):
        self.die_frames += 1

    def handle_left_walk(self):
        self.walk_frames += 1


    def handle_right_die(self):
        self.die_frames += 1


    def handle_right_walk(self):
        self.walk_frames += 1


    handle_state = {
                LEFT_WALK : handle_left_walk,
                RIGHT_WALK : handle_right_walk,
                LEFT_DIE : handle_left_die,
                RIGHT_DIE : handle_right_die
    }

    def update(self, _events):
        for event in _events:
            if event.type == SDL_KEYDOWN and event.key== SDLK_RIGHT:
                self.x += 5
                self.state = self.RIGHT_WALK
            elif event.type == SDL_KEYDOWN and event.key== SDLK_LEFT:
                self.x -= 5
                self.state = self.LEFT_WALK
        self.frame = (self.frame + 1) % 5
        self.handle_state[self.state](self)



    def __init__(self):
        self.x, self.y = 70, 50
        self.walk_frames = 0
        self.die_frames = 0
        self.frame = 0
        self.state = self.RIGHT_WALK
        if self.image == None:
            self.image = load_image('player.png')



    def draw(self):
        if self.state == self.LEFT_WALK:
            self.image.clip_draw(self.frame * 54, self.state * 52, 54, 52, self.x, self.y)
        elif self.state == self.RIGHT_WALK:
            self.image.clip_draw(self.frame * 54, self.state * 52, 54, 52, self.x, self.y)