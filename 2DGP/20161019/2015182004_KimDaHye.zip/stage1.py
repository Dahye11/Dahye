import game_framework
from player_object import *
from monster_object import *
import stage2
from pico2d import *

name = "Stage1"

globalevents = None
player = None
monster1 = None
backimage, stageimage = None, None

def handle_events():
    global globalevents
    globalevents = get_events()
    for event in globalevents:
        if event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                game_framework.quit()
            elif event.key == SDLK_a:
                game_framework.change_state(stage2)
        elif event.type == SDL_QUIT:
            game_framework.quit()


def enter():
    global player, backimage, stageimage, monster1
    open_canvas()
    player = Player()
    monster1 = Monster1()

    backimage = load_image('background1.png')
    stageimage = load_image('stage1.png')

def exit():
    global player, backimage, stageimage, monster1
    del(player)
    del(monster1)
    del(backimage)
    del(stageimage)

def update():
    global player, globalevents, monster1
    player.update(globalevents)
    monster1.update(globalevents)
    delay(0.1)


def draw():
    global player, monster1
    clear_canvas()
    backimage.draw(400, 300)
    stageimage.draw(400, 300)
    player.draw()
    monster1.draw()
    update_canvas()






