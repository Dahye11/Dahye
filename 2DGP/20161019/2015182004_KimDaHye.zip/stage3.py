import game_framework
from player_object import *
from monster_object import *
from pico2d import *

name = "Stage3"

globalevents = None
player, monster1, monster2, backimage, stageimage = None,None,None,None,None

def handle_events():
    global globalevents
    globalevents = get_events()
    for event in globalevents:
        if event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE:
                game_framework.quit()
        elif event.type == SDL_QUIT:
            game_framework.quit()

def enter():
    global player, backimage, stageimage, monster1, monster2
    open_canvas()
    player = Player()
    monster1 = Monster1()
    monster2 = Monster2()

    backimage = load_image('background3.png')
    stageimage = load_image('stage3.png')

def exit():
    global player, backimage, stageimage, monster1, monster2
    del (player)
    del (monster1)
    del (monster2)
    del (backimage)
    del (stageimage)

def update():
    global player, globalevents, monster1, monster2
    player.update(globalevents)
    monster1.update(globalevents)
    monster2.update(globalevents)
    delay(0.1)


def draw():
    global player, backimage, stageimage, monster1, monster2
    clear_canvas()
    backimage.draw(400, 300)
    stageimage.draw(400, 300)
    player.draw()
    monster1.draw()
    monster2.draw()
    update_canvas()







