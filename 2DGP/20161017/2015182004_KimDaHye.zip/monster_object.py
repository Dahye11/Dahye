import sys
sys.path.append('../LabsAll/Labs')

import random
from pico2d import *

start = None
monster1 = None

class Monster1:
    image = None

    LEFT_RUN, RIGHT_RUN = 1, 0


    def handle_left_run(self):
        self.x -= 5
        self.run_frames += 1
        if self.x < 70:
            self.state = self.RIGHT_RUN
            self.x = 70
        pass # fill here



    def handle_right_run(self):
        self.x += 5
        self.run_frames -= 1
        if self.x > 750:
            self.state = self.LEFT_RUN
            self.x = 750
        pass # fill here



    #fill here
    handle_state = {
                LEFT_RUN : handle_left_run,
                RIGHT_RUN : handle_right_run,
    }

    def update(self):
        self.frame = (self.frame + 1) % 12
        self.handle_state[self.state](self)
        pass # fill here



    def __init__(self):
        self.x, self.y = random.randint(100, 700), 90
        self.frame = random.randint(0, 7)
        self.run_frames = 0
        self.stand_frames = 0
        self.state = self.RIGHT_RUN
        if Monster1.image == None:
            Monster1.image = load_image('monster1.PNG')

    def draw(self):
        self.image.clip_draw(self.frame * 40, self.state * 46, 40, 46, self.x, self.y)


def handle_events():
    events = get_events()
    pass

start = True
monster1 = None

def enter():
    global  monster1
    open_canvas()
    monster1 = Monster1()

def exit():
    del(monster1)
    close_canvas()

def update():
    monster1.update()

def draw():
    clear_canvas()
    monster1.draw()
    update_canvas()

def main():
    enter()
    while start:
        handle_events()
        update()
        draw()

    exit()


if __name__ == '__main__':
    main()