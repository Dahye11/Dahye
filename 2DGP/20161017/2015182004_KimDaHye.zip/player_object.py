from pico2d import *

#------플레이어 움직임--------------------
player_leftdie = None
player_rightdie = None
player_leftwalk = None
player_rightwalk = None
#------------------------------------------

move = False
dir = False
#-----------------------------------------

class Player:
    image = None

    LEFT_WALK, RIGHT_WALK, LEFT_DIE, RIGHT_DIE = 3,2,1,0


    def handle_left_die(self):
        self.die_frames += 1
        pass # fill here

    def handle_left_walk(self):
        self.walk_frames += 1
        pass # fill here


    def handle_right_die(self):
        self.die_frames += 1
        pass # fill here


    def handle_right_walk(self):
        self.walk_frames += 1
        pass # fill here



    #fill here
    handle_state = {
                LEFT_WALK : handle_left_walk,
                RIGHT_WALK : handle_right_walk,
                LEFT_DIE : handle_left_die,
                RIGHT_DIE : handle_right_die
    }

    def update(self):
        global player
        global move
        global dir

        if move == True:
            if dir == True:
                self.frame = (self.frame + 1) % 5
                player.x -= 5
            elif dir==False:
                self.frame = (self.frame + 1) % 5
                player.x += 5
        self.handle_state[self.state](self)
        pass # fill here



    def __init__(self):
        self.x, self.y = 70, 50
        self.walk_frames = 0
        self.die_frames = 0
        self.frame = 0
        self.state = self.RIGHT_WALK
        if Player.image == None:
            Player.image = load_image('player.png')



    def draw(self):
        global player

        if player.state == player.LEFT_WALK:
            self.image.clip_draw(self.frame * 54, self.state * 52, 54, 52, self.x, self.y)
        elif player.state == player.RIGHT_WALK:
            self.image.clip_draw(self.frame * 54, self.state * 52, 54, 52, self.x, self.y)


def handle_events():
    global start

    events = get_events()
    for event in events:
        if event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            start = False
        elif event.type == SDL_QUIT:
            start = False
    pass


start = True
player = None
def enter():
    global  player
    open_canvas()
    player = Player()

def exit():
    global player
    del(player)
    close_canvas()

def update():
    global player
    player.update()

def draw():
    global player
    clear_canvas()
    player.draw()
    update_canvas()

def main():
    enter()
    while start:
        handle_events()
        update()
        draw()

    exit()


if __name__ == '__main__':
    main()