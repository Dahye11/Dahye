import random
import json
import os

from pico2d import *

import game_framework
import title_state
import player_object
import stage3

name = "Stage2"

bkg2_1 = None
bkg2_2 = None
stage2 = None
player = None
font = None
logo_time = 0.0

monster2 = None

move = False
dir = False

#------플레이어 움직임--------------------
player_leftdie = None
player_rightdie = None
player_leftwalk = None
player_rightwalk = None
#------------------------------------------

class BKG2_1:
    def __init__(self):
        self.image = load_image('background2_1.png')
    def draw(self):
        self.image.draw(400,300)

class BKG2_2:
    def __init__(self):
        self.image = load_image('background2_2.png')
    def draw(self):
        self.image.draw(400,300)

class Stage2:
    def __init__(self):
        self.image = load_image('stage2.png')
    def draw(self):
        self.image.draw(400,300)

class Monster2:
    image = None

    LEFT_RUN, RIGHT_RUN = 1, 0


    def handle_left_run(self):
        self.x -= 10
        self.run_frames += 1
        if self.x < 100:
            self.state = self.RIGHT_RUN
            self.x = 100
        pass # fill here



    def handle_right_run(self):
        self.x += 10
        self.run_frames -= 1
        if self.x > 700:
            self.state = self.LEFT_RUN
            self.x = 700
        pass # fill here



    #fill here
    handle_state = {
                LEFT_RUN : handle_left_run,
                RIGHT_RUN : handle_right_run,
    }

    def update(self):
        self.frame = (self.frame + 1) % 8
        self.handle_state[self.state](self)
        pass # fill here



    def __init__(self):
        self.x, self.y = random.randint(100, 700), 400
        self.frame = random.randint(0, 7)
        self.run_frames = 0
        self.stand_frames = 0
        self.state = self.RIGHT_RUN
        self.dirY = 1
        if Monster2.image == None:
            Monster2.image = load_image('monster2.PNG')

    def draw(self):
        self.image.clip_draw(self.frame * 50, self.state * 46, 50, 46, self.x, self.y)
        delay(0.03)

class Player:
    image = None

    LEFT_WALK, RIGHT_WALK, LEFT_DIE, RIGHT_DIE = 3,2,1,0


    def handle_left_die(self):
        self.die_frames += 1
        pass # fill here

    def handle_left_walk(self):
        self.walk_frames += 1
        pass # fill here


    def handle_right_die(self):
        self.die_frames += 1
        pass # fill here


    def handle_right_walk(self):
        self.walk_frames += 1
        pass # fill here



    #fill here
    handle_state = {
                LEFT_WALK : handle_left_walk,
                RIGHT_WALK : handle_right_walk,
                LEFT_DIE : handle_left_die,
                RIGHT_DIE : handle_right_die
    }

    def update(self):
        global player
        global move
        global dir

        if move == True:
            if dir == True:
                self.frame = (self.frame + 1) % 5
                player.x -= 5
            elif dir==False:
                self.frame = (self.frame + 1) % 5
                player.x += 5
        self.handle_state[self.state](self)
        delay(0.05)
        pass



    def __init__(self):
        self.x, self.y = 70, 50
        self.walk_frames = 0
        self.die_frames = 0
        self.frame = 0
        self.state = self.RIGHT_WALK
        if Player.image == None:
            Player.image = load_image('player.png')



    def draw(self):
        global player

        if player.state == player.LEFT_WALK:
            self.image.clip_draw(self.frame * 54, self.state * 52, 54, 52, self.x, self.y)
        elif player.state == player.RIGHT_WALK:
            self.image.clip_draw(self.frame * 54, self.state * 52, 54, 52, self.x, self.y)


def enter():
    global player
    global stage2
    global bkg2_1
    global bkg2_2
    global monster2
    bkg2_1 = BKG2_1()
    bkg2_2 = BKG2_2()
    player = Player()
    stage2 = Stage2()
    monster2 = Monster2()
    pass


def exit():
    global player
    global stage2
    global bkg2_1
    global bkg2_2
    global monster2
    del(monster2)
    del(bkg2_1)
    del(bkg2_2)
    del(stage2)
    del(player)
    pass


def pause():
    pass


def resume():
    pass


def handle_events():
    global player
    global start
    global move
    global dir

    events = get_events()
    for event in events:
        if event.type == SDL_KEYDOWN:
            if event.key == SDLK_LEFT:
                player.state = player.LEFT_WALK
                move = True
                dir = True
            elif event.key == SDLK_RIGHT:
                player.state = player.RIGHT_WALK
                move = True
                dir = False
            elif event.key == SDLK_UP:
                player.y += 70
            elif event.key == SDLK_ESCAPE:
                start = False
                game_framework.quit()
            elif event.key == SDLK_a:
                game_framework.change_state(stage3)
        elif event.type == SDL_QUIT:
            start = False
            game_framework.quit()
        elif event.type == SDL_KEYUP:
            move = False


def update():
    monster2.update()
    player.update()
    pass


def draw():
    clear_canvas()
    bkg2_1.draw()
    bkg2_2.draw()
    stage2.draw()
    player.draw()
    monster2.draw()
    update_canvas()
    pass





